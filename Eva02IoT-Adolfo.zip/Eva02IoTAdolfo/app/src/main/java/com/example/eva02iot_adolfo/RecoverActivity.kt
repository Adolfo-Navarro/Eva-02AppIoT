package com.example.eva02iot_adolfo

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AlertDialog

class RecoverActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_recover)

        val etRecoverEmail = findViewById<EditText>(R.id.etRecoverEmail)
        val btnRecover = findViewById<Button>(R.id.btnRecover)
        val btnBackToLogin = findViewById<Button>(R.id.btnBackToLogin)

        btnRecover.setOnClickListener {
            val email = etRecoverEmail.text.toString()

            if (email.isEmpty()) {
                showAlert("Error", "Por favor ingrese su email")
            } else {
                showAlert("Instrucciones Enviadas",
                    "Se han enviado las instrucciones para recuperar su contraseña al email: $email")
            }
        }

        btnBackToLogin.setOnClickListener {
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
            finish()
        }
    }

    private fun showAlert(title: String, message: String) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("Aceptar") { dialog, _ ->
                dialog.dismiss()
                if (title == "Instrucciones Enviadas") {
                    val intent = Intent(this, LoginActivity::class.java)
                    startActivity(intent)
                    finish()
                }
            }
            .create()
            .show()
    }
}