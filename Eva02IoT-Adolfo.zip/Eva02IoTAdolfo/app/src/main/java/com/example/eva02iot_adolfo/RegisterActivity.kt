package com.example.eva02iot_adolfo


import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AlertDialog

class RegisterActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        val etFullName = findViewById<EditText>(R.id.etFullName)
        val etRegisterEmail = findViewById<EditText>(R.id.etRegisterEmail)
        val etRegisterPassword = findViewById<EditText>(R.id.etRegisterPassword)
        val etConfirmPassword = findViewById<EditText>(R.id.etConfirmPassword)
        val btnRegisterAccount = findViewById<Button>(R.id.btnRegisterAccount)
        val btnBackToLogin = findViewById<Button>(R.id.btnBackToLoginFromRegister)

        btnRegisterAccount.setOnClickListener {
            val fullName = etFullName.text.toString()
            val email = etRegisterEmail.text.toString()
            val password = etRegisterPassword.text.toString()
            val confirmPassword = etConfirmPassword.text.toString()

            if (fullName.isEmpty() || email.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
                showAlert("Error", "Por favor complete todos los campos")
            } else if (password != confirmPassword) {
                showAlert("Error", "Las contraseñas no coinciden")
            } else if (password.length < 6) {
                showAlert("Error", "La contraseña debe tener al menos 6 caracteres")
            } else {
                showAlert("Registro Exitoso",
                    "Cuenta creada exitosamente para:\nNombre: $fullName\nEmail: $email")
            }
        }

        btnBackToLogin.setOnClickListener {
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
            finish()
        }
    }

    private fun showAlert(title: String, message: String) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("Aceptar") { dialog, _ ->
                dialog.dismiss()
                if (title == "Registro Exitoso") {
                    val intent = Intent(this, LoginActivity::class.java)
                    startActivity(intent)
                    finish()
                }
            }
            .create()
            .show()
    }
}